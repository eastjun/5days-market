package jun.spring.project.member.service;

import jun.spring.project.member.dto.MemberDTO;

public interface MemberService {

	public MemberDTO checkID(String id);
	
}
