package jun.spring.project.board.service;

import org.springframework.stereotype.Service;

@Service
public class BoardSerivceImp implements BoardService{

}
