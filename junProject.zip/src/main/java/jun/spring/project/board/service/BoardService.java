package jun.spring.project.board.service;

public interface BoardService {

}
